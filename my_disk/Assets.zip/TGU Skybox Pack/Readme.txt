﻿Nobody reads a “readme” for skyboxes, so I might as well make this my artist statement.


Artist Statement:


These four skyboxes are my first in a series of artistic game assets reflecting my vision of a game world. I’m an old-school oil painter and a card-carrying nerd. A gamer since the glory days of the Atari 2600, I have recurring dreams of being a character in my own video game. I’m currently developing the art style for an urban fantasy world. The goal is to produce beautiful and efficient assets that work for a wide range of game genres. If you enjoy these skyboxes, please rate it and leave a comment. Tell me what works, what doesn't and what you’d like to see more of.


Newdawn: Good for an ending or cutscene, very painterly. I decided to leave it very sketchy. Open. A new beginning. 


Doomsday: Good for a Silent Hill type suspense, horror, moody af, this sky was featured in my 2014 oil painting The Hermit.


Urbanlight: There is nothing like that New York City light pollution blotting out all but The One Star in Sight.


Nostalgia: If you know the 16-bit title that inspired this sky, leave a comment. 




If you read this far, thank you for your time. Now go make a game!


Sincerely,


Luiz A. A. Teles


Fine Artist and Founder of Babycake Studio


For updates on upcoming skies and other assets, visit us at luiztelesfineart.wordpress.com
For tech support, you may contact me at luxmaximus@gmail.com